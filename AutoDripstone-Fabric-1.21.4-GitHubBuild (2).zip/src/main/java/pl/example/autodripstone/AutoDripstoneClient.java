package pl.example.autodripstone;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.server.command.CommandManager;

import java.util.HashMap;
import java.util.Map;

public class AutoDripstoneClient implements ClientModInitializer {
    private boolean enabled = false;
    private final Map<BlockPos, Boolean> lastOpenState = new HashMap<>();

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(CommandManager.literal("BD").executes(context -> {
                enabled = !enabled;
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("AutoDripstone: " + (enabled ? "ON" : "OFF")), false);
                }
                return Command.SINGLE_SUCCESS;
            }))
        );
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.currentScreen != null) return;
        BlockPos center = client.player.getBlockPos();
        Map<BlockPos, Boolean> currentlySeen = new HashMap<>();
        for (BlockPos pos : BlockPos.iterateOutwards(center, 4, 3, 4)) {
            BlockState state = client.world.getBlockState(pos);
            if (!(state.getBlock() instanceof TrapdoorBlock)) continue;
            boolean open = state.get(TrapdoorBlock.OPEN);
            BlockPos immutable = pos.toImmutable();
            currentlySeen.put(immutable, open);
            Boolean wasOpen = lastOpenState.get(immutable);
            if (enabled && open && Boolean.FALSE.equals(wasOpen)) tryPlaceDripstone(client);
        }
        lastOpenState.keySet().removeIf(pos -> !currentlySeen.containsKey(pos));
        lastOpenState.putAll(currentlySeen);
    }

    private void tryPlaceDripstone(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(Items.POINTED_DRIPSTONE)) { slot = i; break; }
        }
        if (slot < 0) {
            player.sendMessage(Text.literal("AutoDripstone: Put pointed dripstone on your hotbar."), true);
            return;
        }
        if (client.crosshairTarget instanceof BlockHitResult hit) {
            BlockPos targetPos = hit.getBlockPos();
            BlockState targetState = client.world.getBlockState(targetPos);
            if (!targetState.isIn(BlockTags.AIR) && !targetState.isOf(Blocks.POINTED_DRIPSTONE)
                    && client.world.getBlockState(targetPos.up()).isAir()
                    && targetState.isSideSolidFullSquare(client.world, targetPos, Direction.UP)) {
                placeOnTop(client, slot, targetPos);
                return;
            }
        }
        BlockPos origin = player.getBlockPos();
        for (BlockPos pos : BlockPos.iterateOutwards(origin, 3, 2, 3)) {
            BlockState state = client.world.getBlockState(pos);
            if (state.isAir() || state.isOf(Blocks.POINTED_DRIPSTONE)) continue;
            if (!client.world.getBlockState(pos.up()).isAir()) continue;
            if (!state.isSideSolidFullSquare(client.world, pos, Direction.UP)) continue;
            if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 25.0) continue;
            placeOnTop(client, slot, pos.toImmutable());
            return;
        }
        player.sendMessage(Text.literal("AutoDripstone: No nearby placeable block found."), true);
    }

    private void placeOnTop(MinecraftClient client, int slot, BlockPos supportPos) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;
        int oldSlot = player.getInventory().getSelectedSlot();
        player.getInventory().setSelectedSlot(slot);
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        Vec3d hitPos = new Vec3d(supportPos.getX() + 0.5, supportPos.getY() + 1.0, supportPos.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, supportPos, false);
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        player.getInventory().setSelectedSlot(oldSlot);
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(oldSlot));
    }
}
