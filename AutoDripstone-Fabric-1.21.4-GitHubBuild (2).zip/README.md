# AutoDripstone — Fabric 1.21.4

## How it works
- Type `/BD` in chat to toggle the feature on/off.
- When a nearby trapdoor changes from closed to open, the mod looks for `Pointed Dripstone` in the hotbar.
- It tries to place it on the solid block under your crosshair, or on a nearby solid block with air above it.

## Build the JAR on GitHub
1. Create a repository at https://github.com/new.
2. Extract this ZIP.
3. Upload the *contents* of the extracted folder to the repository root, including the hidden `.github` folder.
4. Open **Actions** and enable Actions if prompted.
5. Open the run named **Build Fabric mod** and wait for it to finish.
6. Download the artifact named `auto-dripstone-fabric-1.21.4` from the completed run.
7. Extract the artifact ZIP and put the `.jar` inside `.minecraft/mods`.

## Requirements and limitations
- Minecraft Java 1.21.4, Fabric Loader, Fabric API, Java 21.
- The server must accept the block placement. This mod cannot bypass server rules.
- Placement is attempted on the block under the crosshair if possible, otherwise on a nearby valid solid block. Test in single-player first.
- `/BD` is a client-side command.
